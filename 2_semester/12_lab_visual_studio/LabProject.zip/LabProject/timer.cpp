#include <chrono>
#include "timer.h"
#include "sort.h"

using namespace std;

double timer(SortFuncInt sortFunc, int* arr, int n) {
    auto start = chrono::high_resolution_clock::now();
    sortFunc(arr, n);
    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> duration = end - start;
    return duration.count();
}

double timer(SortFuncDouble sortFunc, double* arr, int n) {
    auto start = chrono::high_resolution_clock::now();
    sortFunc(arr, n);
    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> duration = end - start;
    return duration.count();
}