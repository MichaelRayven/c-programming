#pragma once
#include "sort.h"

double timer(SortFuncInt sortFunc, int* arr, int n);
double timer(SortFuncDouble sortFunc, double* arr, int n);