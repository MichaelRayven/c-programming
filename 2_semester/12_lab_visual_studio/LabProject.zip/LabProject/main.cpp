#include <iostream>
#include <conio.h>
#include "sort.h"
#include "timer.h"

using namespace std;

void initArray(int* arr, int n) {
    for (int i = 0; i < n; i++) {
        arr[i] = rand() % 10000; 
    }
}

void initArray(double* arr, int n) {
    for (int i = 0; i < n; i++) {
        arr[i] = (double)(rand() % 10000) + (rand() % 100) / 100.0;
    }
}

int main() {
    srand(time(0)); 
    const int n = 10000; 

    // Integer arrays
    int* arr1 = new int[n];
    int* arr2 = new int[n];
    initArray(arr1, n);
    initArray(arr2, n);

    // Double arrays
    double* arr3 = new double[n];
    double* arr4 = new double[n];
    initArray(arr3, n);
    initArray(arr4, n);

    // Measure sorting times
    cout << "Bubble Sort (int): " << timer(bubbleSortInt, arr1, n) << " seconds" << endl;
    cout << "Selection Sort (int): " << timer(selectionSortInt, arr2, n) << " seconds" << endl;
    cout << "Bubble Sort (double): " << timer(bubbleSortDouble, arr3, n) << " seconds" << endl;
    cout << "Selection Sort (double): " << timer(selectionSortDouble, arr4, n) << " seconds" << endl;

    // Clean up
    delete[] arr1;
    delete[] arr2;
    delete[] arr3;
    delete[] arr4;

    cin.get(); 
    return 0;
}