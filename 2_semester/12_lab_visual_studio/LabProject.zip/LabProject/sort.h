#pragma
typedef void (*SortFuncInt)(int*, int);
typedef void (*SortFuncDouble)(double*, int);

void bubbleSortInt(int* arr, int n);
void selectionSortInt(int* arr, int n);

void bubbleSortDouble(double* arr, int n);
void selectionSortDouble(double* arr, int n);

void swap(int& x, int& y);
void swap(double& x, double& y);